/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinicafis;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author ana anaya
 */
class Cita {
    private static int TiempoDeCita = 10; // variable de ámbito de clase que indica el tiempo que tiene asignado cada cita
    private Calendar fecha;
    private TipoEstado estado = TipoEstado.LIBRE;   
    private Medico miMedico;
    
    // A partir del número de cita de esa fecha se calcula la hora de la cita
    // a cada cita se le reservan 10 minutos
    Cita(Calendar fecha, int numeroCita, Medico medico) { 
        this.fecha =(Calendar) fecha.clone();
        this.fecha.set(Calendar.HOUR,9);
        this.fecha.set(Calendar.MINUTE,0);
        this.fecha.add(fecha.MINUTE,numeroCita*TiempoDeCita);
        this.miMedico = medico;
    }
    
    // Redefinición de toString, cuando la cita tenga asignado el Paciente 
    // tendrás que quitar los comentarios que hay en este código
    @Override
    public String toString()
     {
          SimpleDateFormat hmsf = new SimpleDateFormat("hh:mm");
          String salida =  "hora: " + hmsf.format(fecha.getTime()) +" (" + estado.toString()+ ")";
//          if (miPaciente != null)
//              salida += "Paciente: " + miPaciente.getNombre();
          salida +=  "\n";
          return salida;
     }
    
}
