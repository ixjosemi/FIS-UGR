/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clinicafis;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author ana anaya
 */
public class ClinicaFIS {
    // patrón singleton
    private static ClinicaFIS instancia = new ClinicaFIS();
    public static ClinicaFIS getInstance() { 
        return instancia;
    }
    
    // Map en el que se guardan los médicos, la key es el dni del médico
    private Map<String, Medico> misMedicos = new HashMap();       
     
    
    public void nuevoMedico(String dni,String nombre,String especialidad) throws Exception{
        if(existeMedico(dni)) throw new Exception("YA EXISTE UN MÉDICO CON ESE DNI");
        misMedicos.put(dni, new Medico(dni,nombre,especialidad));
    }     

    private boolean existeMedico(String dni) {
         return misMedicos.containsKey(dni);
    }
    
    public void definirAgenda(String dniM,int aPartirDe) throws Exception { 
         Medico unMedico = buscarMedico(dniM);
         unMedico.definirAgenda(aPartirDe);
    }

    private Medico buscarMedico(String dni) throws Exception {
       if(!existeMedico(dni)) throw new  Exception("NO EXISTE EL MÉDICO CON ESE DNI"); 
       return misMedicos.get(dni);
    }

    public List<String> consultarAgenda(String dniM,int numeroDias) throws Exception { 
        Medico unMedico = buscarMedico(dniM);
        return unMedico.obtenerCitas(numeroDias);
    }
    
    public List<String> todosLosMedico(){
        List<String> salida = new ArrayList();
        for (Map.Entry<String, Medico> entry : misMedicos.entrySet()) {            
            Medico unMedico = entry.getValue();
            salida.add(unMedico.toString());
        }
        return salida;
    }
   
    
    
}
